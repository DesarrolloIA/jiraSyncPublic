-- Test Backup File
-- Created: 2025-06-08T03:33:08.597191
-- Purpose: Verify backup system functionality

CREATE TABLE IF NOT EXISTS test_table (
    id INT PRIMARY KEY,
    name VARCHAR(255),
    created_at TIMESTAMP
);

INSERT INTO test_table VALUES 
    (1, 'Test Record 1', NOW()),
    (2, 'Test Record 2', NOW()),
    (3, 'Test Record 3', NOW());

-- End of test backup
